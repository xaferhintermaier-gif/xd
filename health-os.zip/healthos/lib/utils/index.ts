import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, parse, addMinutes, subHours } from "date-fns";

// ─── Class name utility ───────────────────────────────────────────────────────

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Time utilities ───────────────────────────────────────────────────────────

/** Convert "HH:MM" string + offset hours to new "HH:MM" string */
export function subtractHoursFromTime(time: string, hours: number): string {
  const [h, m] = time.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  const result = subHours(date, hours);
  return format(result, "HH:mm");
}

/** Format minutes as "Xh Ym" */
export function formatDuration(minutes: number): string {
  const h = Math.floor(Math.abs(minutes) / 60);
  const m = Math.abs(minutes) % 60;
  const sign = minutes < 0 ? "-" : "";
  if (h === 0) return `${sign}${m}m`;
  if (m === 0) return `${sign}${h}h`;
  return `${sign}${h}h ${m}m`;
}

/** "06:30" → "6:30 AM" */
export function formatTime12h(time: string): string {
  const [h, m] = time.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, "0")} ${period}`;
}

/** Parse ISO date string to display date */
export function formatDisplayDate(date: string): string {
  return format(new Date(date), "EEE, MMM d");
}

// ─── Score computations ───────────────────────────────────────────────────────

/**
 * Compute rolling 14-day sleep debt in minutes.
 * Debt = sum of (target - actual) for each night, clamped to 0 (no credit for oversleeping).
 */
export function computeSleepDebt(
  logs: { durationMinutes: number }[],
  targetMinutes: number
): number {
  return logs.reduce((acc, log) => {
    const deficit = targetMinutes - log.durationMinutes;
    return acc + Math.max(0, deficit);
  }, 0);
}

/**
 * Consistency score: 0–100.
 * Based on std deviation of wake times vs target (in minutes).
 * Score = max(0, 100 - stdDev * 5)
 */
export function computeConsistencyScore(
  wakeTimes: string[],
  targetWakeTime: string
): number {
  if (wakeTimes.length === 0) return 100;

  const [th, tm] = targetWakeTime.split(":").map(Number);
  const targetMinutes = th * 60 + tm;

  const deviations = wakeTimes.map((wt) => {
    const [h, m] = wt.split(":").map(Number);
    return Math.abs(h * 60 + m - targetMinutes);
  });

  const avg = deviations.reduce((a, b) => a + b, 0) / deviations.length;
  const variance = deviations.reduce((a, b) => a + (b - avg) ** 2, 0) / deviations.length;
  const stdDev = Math.sqrt(variance);

  return Math.max(0, Math.round(100 - stdDev * 5));
}

/** Recovery score: average of three 1–10 ratings */
export function computeRecoveryScore(
  sleepQuality: number,
  mood: number,
  energyLevel: number
): number {
  return Math.round(((sleepQuality + mood + energyLevel) / 3) * 10) / 10;
}

/**
 * Circadian schedule from wake time anchor + preferences.
 * All times as HH:MM strings.
 */
export function computeCircadianSchedule(
  wakeTime: string,
  targetBedtime: string,
  caffeineCutoffHours: number,
  blueLightCutoffHours: number,
  targetLastMealTime: string
): {
  wakeTime: string;
  caffeineDeadline: string;
  blueLightCutoff: string;
  targetBedtime: string;
  mealWindowClose: string;
} {
  return {
    wakeTime,
    caffeineDeadline: subtractHoursFromTime(targetBedtime, caffeineCutoffHours),
    blueLightCutoff: subtractHoursFromTime(targetBedtime, blueLightCutoffHours),
    targetBedtime,
    mealWindowClose: targetLastMealTime,
  };
}

// ─── API helpers ──────────────────────────────────────────────────────────────

export function apiSuccess<T>(data: T, meta?: Record<string, unknown>) {
  return Response.json({ data, error: null, meta: meta ?? {} });
}

export function apiError(message: string, status = 400) {
  return Response.json({ data: null, error: message, meta: {} }, { status });
}

/** Generate a random ID (use in edge runtime where crypto.randomUUID is available) */
export function generateId(): string {
  return crypto.randomUUID();
}

// ─── Rate limiting ────────────────────────────────────────────────────────────

export function getRateLimitKey(userId: string, endpoint: string): string {
  return `ratelimit:${userId}:${endpoint}`;
}
