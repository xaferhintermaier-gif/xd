import {
  pgTable,
  text,
  integer,
  boolean,
  timestamp,
  real,
  pgEnum,
  index,
} from "drizzle-orm/pg-core";

// ─── Enums ────────────────────────────────────────────────────────────────────

export const planEnum = pgEnum("plan", ["free", "premium"]);
export const sourceEnum = pgEnum("source", ["manual", "import"]);
export const exerciseTypeEnum = pgEnum("exercise_type", [
  "strength", "cardio", "hiit", "yoga", "sport", "walk", "other",
]);

// ─── Users ────────────────────────────────────────────────────────────────────

export const users = pgTable("users", {
  id: text("id").primaryKey(),            // Clerk user.id
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  avatarUrl: text("avatar_url"),
  timezone: text("timezone").notNull().default("UTC"),
  dateOfBirth: text("date_of_birth"),
  plan: planEnum("plan").notNull().default("free"),
  onboarded: boolean("onboarded").notNull().default(false),
  stripeCustomerId: text("stripe_customer_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ─── Sleep ────────────────────────────────────────────────────────────────────

export const sleepSchedules = pgTable("sleep_schedules", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  wakeTimeAnchor: text("wake_time_anchor").notNull(),   // HH:MM
  targetDurationMinutes: integer("target_duration_minutes").notNull(),
  targetBedtime: text("target_bedtime").notNull(),       // computed, stored
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  userIdx: index("sleep_schedules_user_idx").on(t.userId),
}));

export const sleepLogs = pgTable("sleep_logs", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: text("date").notNull(),                          // ISO date (morning date)
  bedtime: timestamp("bedtime").notNull(),
  wakeTime: timestamp("wake_time").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  deviationMinutes: integer("deviation_minutes").notNull(),
  qualityRating: real("quality_rating"),
  source: sourceEnum("source").notNull().default("manual"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  userDateIdx: index("sleep_logs_user_date_idx").on(t.userId, t.date),
}));

export const sleepDebts = pgTable("sleep_debts", {
  userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  currentDebtMinutes: integer("current_debt_minutes").notNull().default(0),
  weeklyDebtMinutes: integer("weekly_debt_minutes").notNull().default(0),
  consistencyScore: real("consistency_score").notNull().default(100),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// ─── Exercise ─────────────────────────────────────────────────────────────────

export const exerciseGoals = pgTable("exercise_goals", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  sessionsPerWeek: integer("sessions_per_week").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  startDate: text("start_date").notNull(),
}, (t) => ({
  userIdx: index("exercise_goals_user_idx").on(t.userId),
}));

export const exerciseSessions = pgTable("exercise_sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  sessionDate: text("session_date").notNull(),
  sessionTime: text("session_time"),
  durationMinutes: integer("duration_minutes"),
  type: exerciseTypeEnum("type").notNull(),
  intensityRating: real("intensity_rating"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  userDateIdx: index("exercise_sessions_user_date_idx").on(t.userId, t.sessionDate),
}));

export const exerciseStreaks = pgTable("exercise_streaks", {
  userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  currentWeekSessions: integer("current_week_sessions").notNull().default(0),
  currentStreakWeeks: integer("current_streak_weeks").notNull().default(0),
  longestStreakWeeks: integer("longest_streak_weeks").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// ─── Nutrition ────────────────────────────────────────────────────────────────

export const nutritionWindows = pgTable("nutrition_windows", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  targetWindowHours: real("target_window_hours").notNull().default(10),
  targetFirstMealTime: text("target_first_meal_time").notNull(),
  targetLastMealTime: text("target_last_meal_time").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export const mealLogs = pgTable("meal_logs", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  loggedAt: timestamp("logged_at").notNull(),
  mealLabel: text("meal_label"),
  notes: text("notes"),
  isLate: boolean("is_late").notNull().default(false),
  minutesAfterWindow: integer("minutes_after_window").notNull().default(0),
}, (t) => ({
  userIdx: index("meal_logs_user_idx").on(t.userId, t.loggedAt),
}));

// ─── Recovery & Circadian ────────────────────────────────────────────────────

export const morningRecoveries = pgTable("morning_recoveries", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: text("date").notNull(),
  sleepQuality: real("sleep_quality").notNull(),
  mood: real("mood").notNull(),
  energyLevel: real("energy_level").notNull(),
  recoveryScore: real("recovery_score").notNull(),
  loggedAt: timestamp("logged_at").notNull().defaultNow(),
}, (t) => ({
  userDateIdx: index("morning_recoveries_user_date_idx").on(t.userId, t.date),
}));

export const circadianPreferences = pgTable("circadian_preferences", {
  userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  caffeineCutoffHours: real("caffeine_cutoff_hours").notNull().default(8),
  blueLightCutoffHours: real("blue_light_cutoff_hours").notNull().default(2),
  morningLightTargetMinutes: integer("morning_light_target_minutes").notNull().default(10),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ─── Analytics ───────────────────────────────────────────────────────────────

export const weeklyReports = pgTable("weekly_reports", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  weekStartDate: text("week_start_date").notNull(),
  avgSleepDurationMinutes: real("avg_sleep_duration_minutes").notNull(),
  totalSleepDebtMinutes: integer("total_sleep_debt_minutes").notNull(),
  sleepConsistencyScore: real("sleep_consistency_score").notNull(),
  exerciseSessions: integer("exercise_sessions").notNull(),
  exerciseGoalMet: boolean("exercise_goal_met").notNull(),
  avgRecoveryScore: real("avg_recovery_score").notNull(),
  avgEnergyLevel: real("avg_energy_level").notNull(),
  lateMealCount: integer("late_meal_count").notNull(),
  generatedInsights: text("generated_insights").array().notNull().default([]),
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
}, (t) => ({
  userWeekIdx: index("weekly_reports_user_week_idx").on(t.userId, t.weekStartDate),
}));
