import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { morningRecoveries } from "@/lib/db/schema";
import { eq, desc, gte } from "drizzle-orm";
import { format } from "date-fns";
import { PageHeader, ScorePill } from "@/components/ui";
import { RecoveryScoreLine } from "@/components/charts";
import { RecoveryForm } from "@/components/forms";

export const metadata = {
  title: "Recovery",
  robots: { index: false },
};

export default async function RecoveryPage() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const today = format(new Date(), "yyyy-MM-dd");
  const twoWeeksAgo = format(new Date(Date.now() - 14 * 86400000), "yyyy-MM-dd");

  const records = await db
    .select()
    .from(morningRecoveries)
    .where(eq(morningRecoveries.userId, userId))
    .orderBy(desc(morningRecoveries.date))
    .limit(60);

  const todayRecord = records.find((r) => r.date === today) ?? null;
  const chartData = records.filter((r) => r.date >= twoWeeksAgo).reverse();

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Morning Recovery"
        description="How do you feel today?"
      />

      {/* Today's entry */}
      <div className="card p-5">
        {todayRecord ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm font-semibold text-surface-800">Today — {format(new Date(), "MMMM d")}</p>
              <span className="text-xs text-surface-400">Logged at {format(todayRecord.loggedAt, "h:mm a")}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <ScorePill score={todayRecord.sleepQuality} label="Sleep Quality" />
              <ScorePill score={todayRecord.mood} label="Mood" />
              <ScorePill score={todayRecord.energyLevel} label="Energy" />
            </div>
            <div className="mt-3 flex items-center gap-2">
              <span className="text-xs text-surface-400">Recovery score:</span>
              <span className="text-sm font-bold text-brand-600">{todayRecord.recoveryScore.toFixed(1)} / 10</span>
            </div>
          </div>
        ) : (
          <RecoveryForm date={today} />
        )}
      </div>

      {/* Chart */}
      {chartData.length > 0 && (
        <RecoveryScoreLine
          data={chartData.map((r) => ({
            date: r.date,
            sleepQuality: r.sleepQuality,
            mood: r.mood,
            energyLevel: r.energyLevel,
            recoveryScore: r.recoveryScore,
          }))}
        />
      )}

      {/* History */}
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-surface-100">
          <p className="text-sm font-semibold text-surface-800">Recovery Log</p>
        </div>
        <div className="divide-y divide-surface-100">
          {records.map((r) => (
            <div key={r.id} className="flex items-center justify-between px-4 py-3 hover:bg-surface-50">
              <p className="text-sm font-medium text-surface-900">{format(new Date(r.date), "EEE, MMM d")}</p>
              <div className="flex items-center gap-2">
                <ScorePill score={r.sleepQuality} label="Q" />
                <ScorePill score={r.mood} label="M" />
                <ScorePill score={r.energyLevel} label="E" />
                <span className="text-sm font-bold text-brand-600 ml-1">{r.recoveryScore.toFixed(1)}</span>
              </div>
            </div>
          ))}
          {records.length === 0 && (
            <div className="p-8 text-center text-sm text-surface-400">No recovery logs yet</div>
          )}
        </div>
      </div>
    </div>
  );
}
