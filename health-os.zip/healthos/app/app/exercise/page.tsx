import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { exerciseSessions, exerciseStreaks, exerciseGoals } from "@/lib/db/schema";
import { eq, and, desc, gte } from "drizzle-orm";
import { format, startOfWeek, subWeeks } from "date-fns";
import { PageHeader, MetricCard, StreakBadge, EmptyState } from "@/components/ui";
import { ExerciseBarChart } from "@/components/charts";
import { ExerciseWeekCard } from "@/components/dashboard";
import { Dumbbell } from "lucide-react";
import Link from "next/link";

export const metadata = {
  title: "Exercise",
  robots: { index: false },
};

export default async function ExercisePage() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const weekStart = format(startOfWeek(new Date(), { weekStartsOn: 1 }), "yyyy-MM-dd");
  const eightWeeksAgo = format(subWeeks(new Date(), 8), "yyyy-MM-dd");

  const [sessions, streak, goal] = await Promise.all([
    db.select().from(exerciseSessions).where(and(eq(exerciseSessions.userId, userId), gte(exerciseSessions.sessionDate, eightWeeksAgo))).orderBy(desc(exerciseSessions.sessionDate)),
    db.select().from(exerciseStreaks).where(eq(exerciseStreaks.userId, userId)).limit(1).then((r) => r[0] ?? null),
    db.select().from(exerciseGoals).where(and(eq(exerciseGoals.userId, userId), eq(exerciseGoals.isActive, true))).limit(1).then((r) => r[0] ?? null),
  ]);

  const thisWeekSessions = sessions.filter((s) => s.sessionDate >= weekStart);
  const thisMonthSessions = sessions.filter((s) => s.sessionDate >= format(new Date(new Date().getFullYear(), new Date().getMonth(), 1), "yyyy-MM-dd"));

  // Build weekly chart data (8 weeks)
  const weeklyData = Array.from({ length: 8 }, (_, i) => {
    const weekOf = subWeeks(new Date(), 7 - i);
    const weekStartStr = format(startOfWeek(weekOf, { weekStartsOn: 1 }), "yyyy-MM-dd");
    const weekEndStr = format(new Date(new Date(weekStartStr).getTime() + 6 * 86400000), "yyyy-MM-dd");
    const count = sessions.filter((s) => s.sessionDate >= weekStartStr && s.sessionDate <= weekEndStr).length;
    return { week: format(weekOf, "MMM d"), sessions: count };
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Exercise"
        description="Weekly goal tracking and session history"
        actions={
          <Link
            href="/app/exercise/log"
            className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-colors"
          >
            + Log Session
          </Link>
        }
      />

      {/* Metrics */}
      <div className="grid grid-cols-3 gap-3">
        <MetricCard
          label="This Week"
          value={`${thisWeekSessions.length} / ${goal?.sessionsPerWeek ?? 5}`}
          description="sessions"
        />
        <MetricCard
          label="Streak"
          value={streak?.currentStreakWeeks ?? 0}
          unit="weeks"
        />
        <MetricCard
          label="This Month"
          value={thisMonthSessions.length}
          unit="sessions"
        />
      </div>

      {/* Week grid */}
      <ExerciseWeekCard
        sessionsCompleted={thisWeekSessions.length}
        goal={goal ?? { id: "", userId, sessionsPerWeek: 5, isActive: true, startDate: weekStart }}
        streak={streak ?? { userId, currentWeekSessions: 0, currentStreakWeeks: 0, longestStreakWeeks: 0, lastUpdated: new Date() }}
      />

      {/* Weekly bar chart */}
      {sessions.length > 0 && (
        <ExerciseBarChart data={weeklyData} goal={goal?.sessionsPerWeek ?? 5} />
      )}

      {/* Session log */}
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-surface-100">
          <p className="text-sm font-semibold text-surface-800">Session Log</p>
        </div>
        {sessions.length === 0 ? (
          <EmptyState
            icon={<Dumbbell className="w-8 h-8" />}
            title="No sessions yet"
            description="Log your first workout to start tracking."
            action={{ label: "Log session", href: "/app/exercise/log" }}
          />
        ) : (
          <div className="divide-y divide-surface-100">
            {sessions.slice(0, 30).map((s) => (
              <div key={s.id} className="flex items-center justify-between px-4 py-3 hover:bg-surface-50">
                <div>
                  <p className="text-sm font-medium text-surface-900 capitalize">{s.type}</p>
                  <p className="text-xs text-surface-400 mt-0.5">{format(new Date(s.sessionDate), "EEE, MMM d")}</p>
                </div>
                <div className="flex items-center gap-3 text-right">
                  {s.durationMinutes && (
                    <span className="text-xs text-surface-500">{s.durationMinutes} min</span>
                  )}
                  {s.intensityRating && (
                    <span className="text-xs text-surface-500">RPE {s.intensityRating}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
