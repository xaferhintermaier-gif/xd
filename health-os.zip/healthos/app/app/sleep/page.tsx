import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { sleepLogs, sleepDebts, sleepSchedules } from "@/lib/db/schema";
import { eq, and, desc, gte } from "drizzle-orm";
import { format } from "date-fns";
import { PageHeader, MetricCard, SleepDebtMeter, EmptyState } from "@/components/ui";
import { SleepDurationChart, SleepDebtChart } from "@/components/charts";
import { Moon } from "lucide-react";
import Link from "next/link";
import { formatDuration } from "@/lib/utils";

export const metadata = {
  title: "Sleep",
  robots: { index: false },
};

export default async function SleepPage() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const thirtyDaysAgo = format(new Date(Date.now() - 30 * 86400000), "yyyy-MM-dd");

  const [sleepDebt, recentLogs, activeSchedule] = await Promise.all([
    db.select().from(sleepDebts).where(eq(sleepDebts.userId, userId)).limit(1).then((r) => r[0] ?? null),
    db.select().from(sleepLogs).where(and(eq(sleepLogs.userId, userId), gte(sleepLogs.date, thirtyDaysAgo))).orderBy(desc(sleepLogs.date)).limit(30),
    db.select().from(sleepSchedules).where(and(eq(sleepSchedules.userId, userId), eq(sleepSchedules.isActive, true))).limit(1).then((r) => r[0] ?? null),
  ]);

  const avgDuration = recentLogs.length > 0
    ? Math.round(recentLogs.slice(0, 7).reduce((a, l) => a + l.durationMinutes, 0) / Math.min(recentLogs.slice(0, 7).length, 7))
    : 0;

  const chartData = [...recentLogs].reverse().map((l) => ({
    date: l.date,
    durationMinutes: l.durationMinutes,
    targetMinutes: activeSchedule?.targetDurationMinutes ?? 480,
  }));

  const debtChartData = [...recentLogs].reverse().map((l, i) => ({
    date: l.date,
    debtMinutes: Math.max(0, (activeSchedule?.targetDurationMinutes ?? 480) - l.durationMinutes) * (i + 1) / (i + 1),
  }));

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Sleep"
        description="Track your sleep schedule, debt, and consistency"
        actions={
          <Link
            href="/app/sleep/schedule"
            className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-colors"
          >
            Log Sleep
          </Link>
        }
      />

      {/* Metric strip */}
      <div className="grid grid-cols-3 gap-3">
        <MetricCard
          label="Sleep Debt"
          value={formatDuration(sleepDebt?.currentDebtMinutes ?? 0)}
          description="14-day rolling"
        />
        <MetricCard
          label="Consistency"
          value={Math.round(sleepDebt?.consistencyScore ?? 100)}
          unit="/ 100"
          description="7-day score"
        />
        <MetricCard
          label="Avg Duration"
          value={formatDuration(avgDuration)}
          description="Last 7 nights"
        />
      </div>

      {/* Charts */}
      {chartData.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SleepDurationChart data={chartData} />
          <SleepDebtChart data={debtChartData} />
        </div>
      ) : (
        <EmptyState
          icon={<Moon className="w-10 h-10" />}
          title="No sleep logs yet"
          description="Start tracking your sleep to see charts and trends."
          action={{ label: "Log your first night", href: "/app/sleep" }}
        />
      )}

      {/* Schedule */}
      {activeSchedule && (
        <div className="card p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold text-surface-800">Sleep Schedule</p>
            <Link href="/app/sleep/schedule" className="text-xs text-brand-600 font-semibold hover:text-brand-700">
              Edit
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <p className="text-xs text-surface-400">Wake time</p>
              <p className="text-sm font-bold text-surface-900 mt-0.5">{activeSchedule.wakeTimeAnchor}</p>
            </div>
            <div>
              <p className="text-xs text-surface-400">Target bedtime</p>
              <p className="text-sm font-bold text-surface-900 mt-0.5">{activeSchedule.targetBedtime}</p>
            </div>
            <div>
              <p className="text-xs text-surface-400">Target duration</p>
              <p className="text-sm font-bold text-surface-900 mt-0.5">
                {formatDuration(activeSchedule.targetDurationMinutes)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Log list */}
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-surface-100">
          <p className="text-sm font-semibold text-surface-800">Sleep Log</p>
        </div>
        {recentLogs.length === 0 ? (
          <div className="p-8 text-center text-sm text-surface-400">No entries yet</div>
        ) : (
          <div className="divide-y divide-surface-100">
            {recentLogs.map((log) => {
              const deviation = log.deviationMinutes;
              const isOver = deviation >= 0;
              return (
                <div key={log.id} className="flex items-center justify-between px-4 py-3 hover:bg-surface-50 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-surface-900">{format(new Date(log.date), "EEE, MMM d")}</p>
                    <p className="text-xs text-surface-400 mt-0.5">
                      {format(log.bedtime, "h:mm a")} → {format(log.wakeTime, "h:mm a")}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-surface-800 tabular-nums">
                      {formatDuration(log.durationMinutes)}
                    </span>
                    <span className={`text-xs font-medium ${isOver ? "text-emerald-600" : "text-red-500"}`}>
                      {isOver ? "+" : ""}{formatDuration(deviation)}
                    </span>
                    {log.qualityRating && (
                      <span className="text-xs text-surface-400">★ {log.qualityRating}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
