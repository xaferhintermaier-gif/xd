import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { PageHeader, PremiumGate } from "@/components/ui";
import { TrendingUp } from "lucide-react";
import Link from "next/link";

export const metadata = {
  title: "Insights",
  robots: { index: false },
};

const CORRELATION_PRESETS = [
  { label: "Late Meals vs Sleep Quality", x: "minutesAfterWindow", y: "sleepQuality", description: "Does eating late hurt your sleep?" },
  { label: "Exercise vs Morning Energy", x: "exerciseIntensity", y: "energyLevel", description: "How does workout intensity affect next-day energy?" },
  { label: "Sleep Debt vs Mood", x: "sleepDebtMinutes", y: "mood", description: "How does accumulated debt affect your mood?" },
  { label: "Sleep Duration vs Recovery", x: "durationMinutes", y: "recoveryScore", description: "More sleep = better recovery?" },
];

export default async function InsightsPage() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const headersList = headers();
  const plan = headersList.get("x-user-plan") ?? "free";
  const isPremium = plan === "premium";

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Insights"
        description="Cross-metric correlation analysis"
        actions={
          !isPremium && (
            <Link
              href="/app/settings/billing"
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              Upgrade to Premium
            </Link>
          )
        }
      />

      <PremiumGate isLocked={!isPremium}>
        <div className="space-y-4">
          {/* Correlation selector */}
          <div className="card p-4">
            <p className="text-sm font-semibold text-surface-800 mb-3">Custom Correlation</p>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="text-xs font-medium text-surface-500 mb-1 block">X Axis (cause)</label>
                <select className="w-full px-3 py-2 rounded-lg border border-surface-200 text-sm bg-white">
                  <option value="minutesAfterWindow">Late eating (min after window)</option>
                  <option value="sleepDebtMinutes">Sleep debt (minutes)</option>
                  <option value="durationMinutes">Sleep duration (minutes)</option>
                  <option value="exerciseIntensity">Exercise intensity (RPE)</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-surface-500 mb-1 block">Y Axis (effect)</label>
                <select className="w-full px-3 py-2 rounded-lg border border-surface-200 text-sm bg-white">
                  <option value="sleepQuality">Sleep quality (1–10)</option>
                  <option value="mood">Mood (1–10)</option>
                  <option value="energyLevel">Energy level (1–10)</option>
                  <option value="recoveryScore">Recovery score (1–10)</option>
                </select>
              </div>
            </div>
            <button className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-colors">
              Analyze
            </button>
          </div>

          {/* Placeholder chart area */}
          <div className="card p-4">
            <p className="text-sm font-semibold text-surface-800 mb-4">Scatter Plot</p>
            <div className="h-[260px] flex items-center justify-center bg-surface-50 rounded-lg border-2 border-dashed border-surface-200">
              <div className="text-center">
                <TrendingUp className="w-8 h-8 text-surface-300 mx-auto mb-2" />
                <p className="text-sm text-surface-400">Select metrics and click Analyze</p>
              </div>
            </div>
          </div>

          {/* Preset cards */}
          <div>
            <p className="text-sm font-semibold text-surface-800 mb-3">Quick Analysis</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CORRELATION_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  className="card p-4 text-left hover:border-brand-300 hover:shadow-sm transition-all group"
                >
                  <p className="text-sm font-semibold text-surface-800 group-hover:text-brand-700">
                    {preset.label}
                  </p>
                  <p className="text-xs text-surface-500 mt-1">{preset.description}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      </PremiumGate>
    </div>
  );
}
