import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import {
  sleepLogs, sleepDebts, sleepSchedules,
  morningRecoveries, exerciseSessions, exerciseStreaks,
  exerciseGoals, mealLogs, nutritionWindows, circadianPreferences,
} from "@/lib/db/schema";
import { eq, and, desc, gte } from "drizzle-orm";
import { format, startOfWeek } from "date-fns";
import { computeCircadianSchedule } from "@/lib/utils";
import {
  DailyScoreCard,
  TodayScheduleCard,
  ExerciseWeekCard,
  QuickLogBar,
  PendingActionsAlert,
} from "@/components/dashboard";
import { SleepDurationChart } from "@/components/charts";
import { SleepDebtMeter, PageHeader } from "@/components/ui";
import type { PendingLog, CircadianSchedule } from "@/types";

export const metadata = {
  title: "Dashboard",
  robots: { index: false },
};

export default async function DashboardPage() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const today = format(new Date(), "yyyy-MM-dd");
  const weekStart = format(startOfWeek(new Date(), { weekStartsOn: 1 }), "yyyy-MM-dd");
  const fourteenDaysAgo = format(new Date(Date.now() - 14 * 86400000), "yyyy-MM-dd");

  // Parallel data fetching
  const [
    sleepDebt,
    todayRecovery,
    recentSleepLogs,
    exerciseStreak,
    exerciseGoal,
    thisWeekSessions,
    circadianPrefs,
    activeSchedule,
    nutritionWindow,
    todayMeals,
  ] = await Promise.all([
    db.select().from(sleepDebts).where(eq(sleepDebts.userId, userId)).limit(1).then((r) => r[0] ?? null),
    db.select().from(morningRecoveries).where(and(eq(morningRecoveries.userId, userId), eq(morningRecoveries.date, today))).limit(1).then((r) => r[0] ?? null),
    db.select().from(sleepLogs).where(and(eq(sleepLogs.userId, userId), gte(sleepLogs.date, fourteenDaysAgo))).orderBy(desc(sleepLogs.date)).limit(14),
    db.select().from(exerciseStreaks).where(eq(exerciseStreaks.userId, userId)).limit(1).then((r) => r[0] ?? null),
    db.select().from(exerciseGoals).where(and(eq(exerciseGoals.userId, userId), eq(exerciseGoals.isActive, true))).limit(1).then((r) => r[0] ?? null),
    db.select().from(exerciseSessions).where(and(eq(exerciseSessions.userId, userId), gte(exerciseSessions.sessionDate, weekStart))),
    db.select().from(circadianPreferences).where(eq(circadianPreferences.userId, userId)).limit(1).then((r) => r[0] ?? null),
    db.select().from(sleepSchedules).where(and(eq(sleepSchedules.userId, userId), eq(sleepSchedules.isActive, true))).limit(1).then((r) => r[0] ?? null),
    db.select().from(nutritionWindows).where(and(eq(nutritionWindows.userId, userId), eq(nutritionWindows.isActive, true))).limit(1).then((r) => r[0] ?? null),
    db.select().from(mealLogs).where(and(eq(mealLogs.userId, userId), gte(mealLogs.loggedAt, new Date(today)))).orderBy(desc(mealLogs.loggedAt)),
  ]);

  // Build circadian schedule
  const schedule: CircadianSchedule = activeSchedule
    ? computeCircadianSchedule(
        activeSchedule.wakeTimeAnchor,
        activeSchedule.targetBedtime,
        circadianPrefs?.caffeineCutoffHours ?? 8,
        circadianPrefs?.blueLightCutoffHours ?? 2,
        nutritionWindow?.targetLastMealTime ?? "20:00"
      )
    : {
        wakeTime: "07:00",
        caffeineDeadline: "14:00",
        blueLightCutoff: "21:00",
        targetBedtime: "23:00",
        mealWindowClose: "20:00",
      };

  // Pending logs
  const pendingLogs: PendingLog[] = [];
  if (!todayRecovery) pendingLogs.push({ type: "recovery", label: "Morning recovery", href: "/app/recovery" });
  if (recentSleepLogs.length === 0 || recentSleepLogs[0]?.date !== today) {
    pendingLogs.push({ type: "sleep", label: "Last night's sleep", href: "/app/sleep" });
  }

  // Serialize dates for client components
  const debtData = sleepDebt ?? { userId, currentDebtMinutes: 0, weeklyDebtMinutes: 0, consistencyScore: 100, lastUpdated: new Date() };

  const chartData = recentSleepLogs.slice(0, 7).reverse().map((l) => ({
    date: l.date,
    durationMinutes: l.durationMinutes,
    targetMinutes: activeSchedule?.targetDurationMinutes ?? 480,
  }));

  return (
    <div className="space-y-4 animate-fade-in">
      <PageHeader
        title={`Good ${getTimeOfDay()}`}
        description={format(new Date(), "EEEE, MMMM d")}
        actions={
          <span className="text-xs text-surface-400 font-medium">{today}</span>
        }
      />

      {/* Today's schedule strip */}
      <TodayScheduleCard schedule={schedule} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Main column */}
        <div className="md:col-span-2 space-y-4">
          <DailyScoreCard sleepDebt={debtData as any} todayRecovery={todayRecovery as any} />

          <ExerciseWeekCard
            sessionsCompleted={thisWeekSessions.length}
            goal={exerciseGoal ?? { id: "", userId, sessionsPerWeek: 5, isActive: true, startDate: today }}
            streak={exerciseStreak ?? { userId, currentWeekSessions: 0, currentStreakWeeks: 0, longestStreakWeeks: 0, lastUpdated: new Date() }}
          />

          {chartData.length > 0 && <SleepDurationChart data={chartData} />}

          {pendingLogs.length > 0 && <PendingActionsAlert pendingLogs={pendingLogs} />}
        </div>

        {/* Sidebar column */}
        <div className="space-y-4">
          <SleepDebtMeter debtMinutes={debtData.currentDebtMinutes} />
          <QuickLogBar />
        </div>
      </div>
    </div>
  );
}

function getTimeOfDay(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  return "evening";
}
