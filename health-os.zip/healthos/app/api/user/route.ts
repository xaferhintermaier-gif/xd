// app/api/user/route.ts
import { auth, currentUser } from "@clerk/nextjs/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { users } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { apiSuccess, apiError } from "@/lib/utils";

const updateSchema = z.object({
  displayName: z.string().min(1).max(100).optional(),
  timezone: z.string().optional(),
  dateOfBirth: z.string().optional(),
});

export async function GET() {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return apiError("User not found", 404);

  return apiSuccess(user);
}

export async function PATCH(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const body = await req.json();
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.message);

  const [updated] = await db
    .update(users)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(users.id, userId))
    .returning();

  return apiSuccess(updated);
}

export async function DELETE() {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  // Cascade deletes all related records via FK
  await db.delete(users).where(eq(users.id, userId));

  return new Response(null, { status: 204 });
}
