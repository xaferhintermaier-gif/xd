import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { mealLogs, nutritionWindows } from "@/lib/db/schema";
import { eq, and, desc, gte } from "drizzle-orm";
import { generateId, apiSuccess, apiError } from "@/lib/utils";
import { format, parse, differenceInMinutes } from "date-fns";

const createSchema = z.object({
  loggedAt: z.string(),
  mealLabel: z.string().optional(),
  notes: z.string().max(300).optional(),
});

export async function GET(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const url = new URL(req.url);
  const date = url.searchParams.get("date");
  const from = url.searchParams.get("from");

  const conditions = [eq(mealLogs.userId, userId)];
  if (from) conditions.push(gte(mealLogs.loggedAt, new Date(from)));

  const meals = await db
    .select()
    .from(mealLogs)
    .where(and(...conditions))
    .orderBy(desc(mealLogs.loggedAt))
    .limit(100);

  const filtered = date
    ? meals.filter((m) => format(m.loggedAt, "yyyy-MM-dd") === date)
    : meals;

  return apiSuccess(filtered);
}

export async function POST(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.message);

  const loggedAt = new Date(parsed.data.loggedAt);
  const loggedTimeStr = format(loggedAt, "HH:mm");

  // Get nutrition window to compute isLate
  const [window] = await db
    .select()
    .from(nutritionWindows)
    .where(and(eq(nutritionWindows.userId, userId), eq(nutritionWindows.isActive, true)))
    .limit(1);

  let isLate = false;
  let minutesAfterWindow = 0;

  if (window) {
    const [h, m] = loggedTimeStr.split(":").map(Number);
    const [th, tm] = window.targetLastMealTime.split(":").map(Number);
    const loggedMinutes = h * 60 + m;
    const targetMinutes = th * 60 + tm;
    minutesAfterWindow = Math.max(0, loggedMinutes - targetMinutes);
    isLate = minutesAfterWindow > 0;
  }

  const [meal] = await db.insert(mealLogs).values({
    id: generateId(),
    userId,
    loggedAt,
    mealLabel: parsed.data.mealLabel ?? null,
    notes: parsed.data.notes ?? null,
    isLate,
    minutesAfterWindow,
  }).returning();

  return apiSuccess(meal);
}
