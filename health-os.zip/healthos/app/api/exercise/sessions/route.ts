import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { exerciseSessions, exerciseStreaks, exerciseGoals } from "@/lib/db/schema";
import { eq, and, desc, gte } from "drizzle-orm";
import { generateId, apiSuccess, apiError } from "@/lib/utils";
import { startOfWeek, format } from "date-fns";

const exerciseTypeEnum = z.enum(["strength", "cardio", "hiit", "yoga", "sport", "walk", "other"]);

const createSchema = z.object({
  sessionDate: z.string(),
  type: exerciseTypeEnum,
  durationMinutes: z.number().min(1).max(480).optional(),
  intensityRating: z.number().min(1).max(10).optional(),
  notes: z.string().max(500).optional(),
  sessionTime: z.string().optional(),
});

export async function GET(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const url = new URL(req.url);
  const from = url.searchParams.get("from");
  const limit = Math.min(Number(url.searchParams.get("limit") ?? 50), 200);

  const conditions = [eq(exerciseSessions.userId, userId)];
  if (from) conditions.push(gte(exerciseSessions.sessionDate, from));

  const sessions = await db
    .select()
    .from(exerciseSessions)
    .where(and(...conditions))
    .orderBy(desc(exerciseSessions.sessionDate))
    .limit(limit);

  return apiSuccess(sessions);
}

export async function POST(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.message);

  const [session] = await db.insert(exerciseSessions).values({
    id: generateId(),
    userId,
    ...parsed.data,
    durationMinutes: parsed.data.durationMinutes ?? null,
    intensityRating: parsed.data.intensityRating ?? null,
    notes: parsed.data.notes ?? null,
    sessionTime: parsed.data.sessionTime ?? null,
  }).returning();

  // Update streak: count sessions this week
  const weekStart = format(startOfWeek(new Date(), { weekStartsOn: 1 }), "yyyy-MM-dd");
  const thisWeekSessions = await db
    .select()
    .from(exerciseSessions)
    .where(and(eq(exerciseSessions.userId, userId), gte(exerciseSessions.sessionDate, weekStart)));

  const currentWeekSessions = thisWeekSessions.length;

  // Get goal to check if met
  const [goal] = await db
    .select()
    .from(exerciseGoals)
    .where(and(eq(exerciseGoals.userId, userId), eq(exerciseGoals.isActive, true)))
    .limit(1);

  const existing = await db
    .select()
    .from(exerciseStreaks)
    .where(eq(exerciseStreaks.userId, userId))
    .limit(1);

  const currentStreak = existing[0]?.currentStreakWeeks ?? 0;
  const longest = existing[0]?.longestStreakWeeks ?? 0;

  await db
    .insert(exerciseStreaks)
    .values({ userId, currentWeekSessions, currentStreakWeeks: currentStreak, longestStreakWeeks: longest })
    .onConflictDoUpdate({
      target: exerciseStreaks.userId,
      set: { currentWeekSessions, lastUpdated: new Date() },
    });

  return apiSuccess({ session, currentWeekSessions });
}
