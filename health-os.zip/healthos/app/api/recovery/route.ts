import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { morningRecoveries } from "@/lib/db/schema";
import { eq, and, desc, gte } from "drizzle-orm";
import { generateId, apiSuccess, apiError, computeRecoveryScore } from "@/lib/utils";

const createSchema = z.object({
  date: z.string(),
  sleepQuality: z.number().min(1).max(10),
  mood: z.number().min(1).max(10),
  energyLevel: z.number().min(1).max(10),
});

export async function GET(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const url = new URL(req.url);
  const from = url.searchParams.get("from");

  const conditions = [eq(morningRecoveries.userId, userId)];
  if (from) conditions.push(gte(morningRecoveries.date, from));

  const records = await db
    .select()
    .from(morningRecoveries)
    .where(and(...conditions))
    .orderBy(desc(morningRecoveries.date))
    .limit(60);

  return apiSuccess(records);
}

export async function POST(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.message);

  const { date, sleepQuality, mood, energyLevel } = parsed.data;
  const recoveryScore = computeRecoveryScore(sleepQuality, mood, energyLevel);

  const [record] = await db.insert(morningRecoveries).values({
    id: generateId(),
    userId,
    date,
    sleepQuality,
    mood,
    energyLevel,
    recoveryScore,
    loggedAt: new Date(),
  }).returning();

  return apiSuccess(record);
}
