import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { sleepLogs, sleepSchedules, sleepDebts } from "@/lib/db/schema";
import { eq, and, desc, gte, lte } from "drizzle-orm";
import { generateId, apiSuccess, apiError, computeSleepDebt } from "@/lib/utils";
import { format, differenceInMinutes } from "date-fns";

const createSchema = z.object({
  bedtime: z.string(),
  wakeTime: z.string(),
  date: z.string().optional(),
  qualityRating: z.number().min(1).max(10).optional(),
});

export async function GET(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const url = new URL(req.url);
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const limit = Math.min(Number(url.searchParams.get("limit") ?? 50), 100);

  const conditions = [eq(sleepLogs.userId, userId)];
  if (from) conditions.push(gte(sleepLogs.date, from));
  if (to) conditions.push(lte(sleepLogs.date, to));

  const logs = await db
    .select()
    .from(sleepLogs)
    .where(and(...conditions))
    .orderBy(desc(sleepLogs.date))
    .limit(limit);

  return apiSuccess(logs);
}

export async function POST(req: Request) {
  const { userId } = await auth();
  if (!userId) return apiError("Unauthorized", 401);

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.message);

  const { bedtime, wakeTime, qualityRating, date } = parsed.data;

  const bedtimeDate = new Date(bedtime);
  const wakeTimeDate = new Date(wakeTime);
  const durationMinutes = differenceInMinutes(wakeTimeDate, bedtimeDate);

  if (durationMinutes < 60 || durationMinutes > 1440) {
    return apiError("Invalid sleep duration (must be 1–24 hours)");
  }

  // Get active schedule for deviation calculation
  const [schedule] = await db
    .select()
    .from(sleepSchedules)
    .where(and(eq(sleepSchedules.userId, userId), eq(sleepSchedules.isActive, true)))
    .limit(1);

  const targetMinutes = schedule?.targetDurationMinutes ?? 480;
  const deviationMinutes = durationMinutes - targetMinutes;
  const logDate = date ?? format(wakeTimeDate, "yyyy-MM-dd");

  const id = generateId();
  const [log] = await db.insert(sleepLogs).values({
    id,
    userId,
    date: logDate,
    bedtime: bedtimeDate,
    wakeTime: wakeTimeDate,
    durationMinutes,
    deviationMinutes,
    qualityRating: qualityRating ?? null,
    source: "manual",
  }).returning();

  // Recompute sleep debt (last 14 days)
  const twoWeeksAgo = new Date();
  twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);

  const recentLogs = await db
    .select()
    .from(sleepLogs)
    .where(and(
      eq(sleepLogs.userId, userId),
      gte(sleepLogs.date, format(twoWeeksAgo, "yyyy-MM-dd"))
    ));

  const currentDebtMinutes = computeSleepDebt(recentLogs, targetMinutes);

  await db
    .insert(sleepDebts)
    .values({ userId, currentDebtMinutes, weeklyDebtMinutes: 0, consistencyScore: 80 })
    .onConflictDoUpdate({
      target: sleepDebts.userId,
      set: { currentDebtMinutes, lastUpdated: new Date() },
    });

  return apiSuccess({ log, debtMinutes: currentDebtMinutes }, {});
}
