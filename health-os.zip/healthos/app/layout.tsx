import type { Metadata, Viewport } from "next";
import { ClerkProvider } from "@clerk/nextjs";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://healthos.app"),
  title: {
    default: "Health OS — Sleep, Circadian & Performance Tracking",
    template: "%s | Health OS",
  },
  description:
    "Track sleep debt, circadian alignment, exercise, nutrition timing, and morning recovery. Built for analytical people who optimize with data.",
  keywords: [
    "sleep tracking",
    "sleep debt",
    "circadian rhythm",
    "exercise tracking",
    "nutrition timing",
    "recovery score",
    "biohacking",
    "quantified self",
  ],
  authors: [{ name: "Health OS" }],
  creator: "Health OS",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://healthos.app",
    siteName: "Health OS",
    title: "Health OS — Sleep, Circadian & Performance Tracking",
    description:
      "Track sleep debt, circadian alignment, exercise, nutrition timing, and morning recovery.",
    images: [{ url: "/og/home.png", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Health OS — Sleep, Circadian & Performance Tracking",
    description:
      "Track sleep debt, circadian alignment, exercise, nutrition timing, and recovery.",
    images: ["/og/home.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#00C2A8",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html
        lang="en"
        className={`${GeistSans.variable} ${GeistMono.variable}`}
        suppressHydrationWarning
      >
        <body className="bg-surface-50 text-surface-900 antialiased font-sans">
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
