import type { Metadata } from "next";
import Link from "next/link";
import { Moon, Dumbbell, Utensils, Sun, TrendingUp, Zap, ArrowRight, Check } from "lucide-react";

export const metadata: Metadata = {
  title: "Health OS — Sleep, Circadian & Performance Tracking",
  description: "Track sleep debt, circadian alignment, exercise, nutrition timing, and morning recovery. Built for analytical people who optimize with data.",
};

const FEATURES = [
  {
    icon: Moon,
    title: "Sleep Debt Tracking",
    description: "Fixed wake-time anchoring with rolling 14-day debt calculation and consistency scoring.",
    color: "bg-indigo-50 text-indigo-600",
  },
  {
    icon: Zap,
    title: "Circadian Alignment",
    description: "Personalized caffeine cutoffs, blue light schedules, and morning light targets based on your wake time.",
    color: "bg-amber-50 text-amber-600",
  },
  {
    icon: Dumbbell,
    title: "Exercise Adherence",
    description: "User-defined weekly session goals with streak tracking and multi-week trend analysis.",
    color: "bg-emerald-50 text-emerald-600",
  },
  {
    icon: Utensils,
    title: "Nutrition Timing",
    description: "Eating window analysis with late-meal detection correlated against sleep quality.",
    color: "bg-rose-50 text-rose-600",
  },
  {
    icon: Sun,
    title: "Morning Recovery",
    description: "Daily sleep quality, mood, and energy ratings with composite recovery scoring.",
    color: "bg-orange-50 text-orange-600",
  },
  {
    icon: TrendingUp,
    title: "Correlation Engine",
    description: "Cross-metric scatter analysis showing how late meals, sleep debt, and exercise actually affect each other.",
    color: "bg-brand-50 text-brand-600",
  },
];

const FREE_FEATURES = [
  "Sleep debt tracking (14-day rolling)",
  "Circadian schedule generator",
  "Exercise goal tracking",
  "Nutrition eating window log",
  "Morning recovery log",
  "Weekly summary reports",
];

const PREMIUM_FEATURES = [
  "Everything in Free",
  "Correlation analysis engine",
  "Historical data (unlimited)",
  "Advanced CSV + JSON export",
  "Weekly email digest",
  "API access (v1)",
];

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-surface-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-brand-500 flex items-center justify-center">
              <span className="text-white font-bold text-sm">H</span>
            </div>
            <span className="font-bold text-surface-900 text-sm tracking-tight">Health OS</span>
          </Link>
          <div className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm text-surface-600 hover:text-surface-900 transition-colors">Features</Link>
            <Link href="/how-it-works" className="text-sm text-surface-600 hover:text-surface-900 transition-colors">How it works</Link>
            <Link href="/pricing" className="text-sm text-surface-600 hover:text-surface-900 transition-colors">Pricing</Link>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/sign-in" className="text-sm font-medium text-surface-600 hover:text-surface-900 transition-colors">
              Sign in
            </Link>
            <Link
              href="/sign-up"
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              Start free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-brand-50 border border-brand-200 rounded-full mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-500 animate-pulse" />
            <span className="text-xs font-semibold text-brand-700">Behavioral optimization platform</span>
          </div>
          <h1 className="text-5xl sm:text-6xl font-extrabold text-surface-900 tracking-tight leading-[1.08]">
            Your sleep debt is<br />
            <span className="text-brand-500">costing you more</span><br />
            than sleep.
          </h1>
          <p className="mt-6 text-lg text-surface-500 max-w-2xl mx-auto leading-relaxed">
            Health OS tracks sleep debt, circadian alignment, exercise adherence, and nutrition timing—then shows you how they connect. Built for people who want data, not motivation.
          </p>
          <div className="mt-8 flex items-center justify-center gap-3">
            <Link
              href="/sign-up"
              className="flex items-center gap-2 px-6 py-3 bg-brand-500 hover:bg-brand-600 text-white font-semibold rounded-xl transition-colors shadow-lg shadow-brand-500/25"
            >
              Start free <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/how-it-works"
              className="px-6 py-3 border border-surface-200 text-surface-700 font-semibold rounded-xl hover:bg-surface-50 transition-colors"
            >
              See how it works
            </Link>
          </div>
          <p className="mt-4 text-xs text-surface-400">Free forever. No credit card required.</p>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 sm:px-6 bg-surface-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-surface-900">Every variable. One platform.</h2>
            <p className="mt-3 text-surface-500">Six interconnected tracking modules designed to reveal patterns you can't see manually.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map((feature) => (
              <div key={feature.title} className="bg-white rounded-xl border border-surface-200 p-5 hover:shadow-sm transition-shadow">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${feature.color}`}>
                  <feature.icon className="w-4 h-4" />
                </div>
                <h3 className="font-semibold text-surface-900 mb-1.5">{feature.title}</h3>
                <p className="text-sm text-surface-500 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Science */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-surface-900 text-center mb-12">Built on sleep science</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                stat: "2×",
                label: "Increased error rate",
                description: "After 17+ hours of wakefulness, cognitive performance degrades equivalent to 0.05% BAC.",
                citation: "Van Dongen et al., 2003",
              },
              {
                stat: "~24h",
                label: "Circadian cycle length",
                description: "Consistent wake times are the primary zeitgeber that anchors your circadian rhythm.",
                citation: "Czeisler et al., 1999",
              },
              {
                stat: "3+ hrs",
                label: "Meal-sleep gap needed",
                description: "Late eating elevates core body temperature, directly suppressing melatonin onset.",
                citation: "Crispim et al., 2011",
              },
            ].map((item) => (
              <div key={item.stat} className="text-center">
                <p className="text-4xl font-extrabold text-brand-500">{item.stat}</p>
                <p className="font-semibold text-surface-900 mt-1">{item.label}</p>
                <p className="text-sm text-surface-500 mt-2 leading-relaxed">{item.description}</p>
                <p className="text-xs text-surface-400 mt-2 italic">{item.citation}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-4 sm:px-6 bg-surface-50">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-surface-900 text-center mb-12">Simple pricing</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Free */}
            <div className="bg-white rounded-2xl border border-surface-200 p-6">
              <h3 className="font-bold text-surface-900 text-lg">Free</h3>
              <p className="text-3xl font-extrabold text-surface-900 mt-2">$0<span className="text-base font-normal text-surface-400">/mo</span></p>
              <p className="text-sm text-surface-500 mt-1">Everything you need to start.</p>
              <ul className="mt-5 space-y-2.5">
                {FREE_FEATURES.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-surface-700">
                    <Check className="w-4 h-4 text-brand-500 shrink-0" />{f}
                  </li>
                ))}
              </ul>
              <Link href="/sign-up" className="mt-6 block w-full text-center py-2.5 border border-surface-200 rounded-xl font-semibold text-sm text-surface-700 hover:bg-surface-50 transition-colors">
                Get started free
              </Link>
            </div>
            {/* Premium */}
            <div className="bg-surface-900 rounded-2xl p-6 relative overflow-hidden">
              <div className="absolute top-3 right-3 px-2.5 py-1 bg-brand-500 rounded-full text-[11px] font-bold text-white">
                PREMIUM
              </div>
              <h3 className="font-bold text-white text-lg">Premium</h3>
              <p className="text-3xl font-extrabold text-white mt-2">$9<span className="text-base font-normal text-surface-400">/mo</span></p>
              <p className="text-sm text-surface-400 mt-1">For serious optimizers.</p>
              <ul className="mt-5 space-y-2.5">
                {PREMIUM_FEATURES.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-surface-300">
                    <Check className="w-4 h-4 text-brand-400 shrink-0" />{f}
                  </li>
                ))}
              </ul>
              <Link href="/sign-up" className="mt-6 block w-full text-center py-2.5 bg-brand-500 hover:bg-brand-400 rounded-xl font-semibold text-sm text-white transition-colors">
                Start with Premium
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-surface-900">Start tracking tonight.</h2>
          <p className="mt-3 text-surface-500">Log your first night's sleep in under 60 seconds. Free forever.</p>
          <Link
            href="/sign-up"
            className="mt-6 inline-flex items-center gap-2 px-8 py-3.5 bg-brand-500 hover:bg-brand-600 text-white font-bold rounded-xl transition-colors shadow-lg shadow-brand-500/25"
          >
            Create free account <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-surface-100 py-10 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-brand-500 flex items-center justify-center">
              <span className="text-white font-bold text-xs">H</span>
            </div>
            <span className="text-sm font-semibold text-surface-700">Health OS</span>
          </div>
          <div className="flex items-center gap-6">
            <Link href="/legal/privacy" className="text-xs text-surface-400 hover:text-surface-600">Privacy</Link>
            <Link href="/legal/terms" className="text-xs text-surface-400 hover:text-surface-600">Terms</Link>
            <Link href="/changelog" className="text-xs text-surface-400 hover:text-surface-600">Changelog</Link>
          </div>
          <p className="text-xs text-surface-400">© 2025 Health OS</p>
        </div>
      </footer>
    </main>
  );
}
