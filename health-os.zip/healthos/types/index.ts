// ─── Core Domain Types ────────────────────────────────────────────────────────

export interface User {
  id: string;
  email: string;
  displayName: string;
  avatarUrl: string | null;
  timezone: string;
  dateOfBirth: string | null;
  plan: "free" | "premium";
  onboarded: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// ─── Sleep ────────────────────────────────────────────────────────────────────

export interface SleepSchedule {
  id: string;
  userId: string;
  wakeTimeAnchor: string;        // "06:30" HH:MM 24h
  targetDurationMinutes: number;
  targetBedtime: string;         // computed
  isActive: boolean;
  createdAt: Date;
}

export interface SleepLog {
  id: string;
  userId: string;
  date: string;                  // ISO date — morning date
  bedtime: Date;
  wakeTime: Date;
  durationMinutes: number;       // computed
  deviationMinutes: number;      // computed; negative = under target
  qualityRating: number | null;  // 1–10
  source: "manual" | "import";
  createdAt: Date;
}

export interface SleepDebt {
  userId: string;
  currentDebtMinutes: number;
  weeklyDebtMinutes: number;
  consistencyScore: number;      // 0–100
  lastUpdated: Date;
}

// ─── Exercise ─────────────────────────────────────────────────────────────────

export type ExerciseType =
  | "strength"
  | "cardio"
  | "hiit"
  | "yoga"
  | "sport"
  | "walk"
  | "other";

export interface ExerciseGoal {
  id: string;
  userId: string;
  sessionsPerWeek: number;
  isActive: boolean;
  startDate: string;
}

export interface ExerciseSession {
  id: string;
  userId: string;
  sessionDate: string;
  sessionTime: string | null;    // HH:MM
  durationMinutes: number | null;
  type: ExerciseType;
  intensityRating: number | null; // 1–10 RPE
  notes: string | null;
  createdAt: Date;
}

export interface ExerciseStreak {
  userId: string;
  currentWeekSessions: number;
  currentStreakWeeks: number;
  longestStreakWeeks: number;
  lastUpdated: Date;
}

// ─── Nutrition ────────────────────────────────────────────────────────────────

export interface NutritionWindow {
  id: string;
  userId: string;
  targetWindowHours: number;
  targetFirstMealTime: string;   // HH:MM
  targetLastMealTime: string;    // HH:MM
  isActive: boolean;
}

export interface MealLog {
  id: string;
  userId: string;
  loggedAt: Date;
  mealLabel: string | null;
  notes: string | null;
  isLate: boolean;               // computed
  minutesAfterWindow: number;    // computed; 0 if within window
}

// ─── Recovery & Circadian ────────────────────────────────────────────────────

export interface MorningRecovery {
  id: string;
  userId: string;
  date: string;
  sleepQuality: number;          // 1–10
  mood: number;                  // 1–10
  energyLevel: number;           // 1–10
  recoveryScore: number;         // computed average
  loggedAt: Date;
}

export interface CircadianPreferences {
  userId: string;
  caffeineCutoffHours: number;
  blueLightCutoffHours: number;
  morningLightTargetMinutes: number;
  updatedAt: Date;
}

export interface CircadianSchedule {
  wakeTime: string;
  caffeineDeadline: string;
  blueLightCutoff: string;
  targetBedtime: string;
  mealWindowClose: string;
}

// ─── Analytics ───────────────────────────────────────────────────────────────

export interface WeeklyReport {
  id: string;
  userId: string;
  weekStartDate: string;
  avgSleepDurationMinutes: number;
  totalSleepDebtMinutes: number;
  sleepConsistencyScore: number;
  exerciseSessions: number;
  exerciseGoalMet: boolean;
  avgRecoveryScore: number;
  avgEnergyLevel: number;
  lateMealCount: number;
  generatedInsights: string[];
  generatedAt: Date;
}

export interface CorrelationDataPoint {
  date: string;
  xMetric: string;
  xValue: number;
  yMetric: string;
  yValue: number;
}

// ─── API Shapes ───────────────────────────────────────────────────────────────

export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  meta?: {
    cursor?: string;
    hasMore?: boolean;
    total?: number;
  };
}

export type TrendDirection = "up" | "down" | "flat";

export interface DashboardData {
  sleepDebt: SleepDebt;
  todayRecovery: MorningRecovery | null;
  lastSleepLog: SleepLog | null;
  exerciseStreak: ExerciseStreak;
  exerciseGoal: ExerciseGoal;
  circadianSchedule: CircadianSchedule;
  todayMeals: MealLog[];
  recentSleepLogs: SleepLog[];
  pendingLogs: PendingLog[];
}

export interface PendingLog {
  type: "sleep" | "recovery" | "exercise" | "meal";
  label: string;
  href: string;
}

// ─── Billing ─────────────────────────────────────────────────────────────────

export interface BillingStatus {
  plan: "free" | "premium";
  status: "active" | "canceled" | "past_due" | "trialing" | null;
  renewalDate: string | null;
}
