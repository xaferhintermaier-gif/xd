# Health OS

Behavioral optimization platform for sleep, circadian alignment, exercise, and nutrition tracking.

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS 3 |
| Auth | Clerk |
| Database | Neon (Postgres 16) + Drizzle ORM |
| Cache | Vercel KV (Upstash Redis) |
| Email | Resend |
| Payments | Stripe |
| Hosting | Vercel |

## Getting Started

### 1. Clone and install

```bash
git clone https://github.com/your-org/health-os.git
cd health-os
npm install
```

### 2. Configure environment

```bash
cp .env.example .env.local
```

Fill in all values in `.env.local`. Required at minimum:
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` + `CLERK_SECRET_KEY` — from [clerk.com](https://clerk.com)
- `DATABASE_URL` — from [neon.tech](https://neon.tech)
- `UPSTASH_REDIS_REST_URL` + `UPSTASH_REDIS_REST_TOKEN` — from [upstash.com](https://upstash.com)

### 3. Set up the database

```bash
npm run db:generate   # Generate SQL migrations from schema
npm run db:migrate    # Apply migrations to Neon
```

### 4. Configure Clerk

In your Clerk dashboard:
1. Enable Email + OAuth providers
2. Add webhook endpoint: `https://your-domain.com/api/webhook/clerk`
3. Subscribe to events: `user.created`, `user.deleted`
4. Copy webhook secret to `CLERK_WEBHOOK_SECRET`

### 5. Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Project Structure

```
health-os/
├── app/
│   ├── app/                    # Authenticated app routes (/app/*)
│   │   ├── dashboard/          # Daily dashboard
│   │   ├── sleep/              # Sleep hub
│   │   ├── exercise/           # Exercise tracking
│   │   ├── nutrition/          # Nutrition timing
│   │   ├── recovery/           # Morning recovery
│   │   ├── insights/           # Correlation engine (Premium)
│   │   └── settings/           # User settings
│   ├── api/                    # Route handlers
│   │   ├── sleep/logs/
│   │   ├── exercise/sessions/
│   │   ├── nutrition/meals/
│   │   ├── recovery/
│   │   ├── user/
│   │   ├── billing/
│   │   └── webhook/
│   ├── layout.tsx              # Root layout (Clerk, fonts)
│   └── page.tsx                # Marketing landing page
├── components/
│   ├── layout/                 # Sidebar, MobileBottomNav
│   ├── dashboard/              # DailyScoreCard, ExerciseWeekCard, etc.
│   ├── charts/                 # Recharts wrappers
│   ├── forms/                  # RHF form components
│   └── ui/                     # Primitives: MetricCard, ProgressRing, etc.
├── lib/
│   ├── db/
│   │   ├── index.ts            # Drizzle client
│   │   └── schema.ts           # Full DB schema
│   └── utils/
│       └── index.ts            # cn(), computations, formatters
├── types/
│   └── index.ts                # All TypeScript interfaces
├── middleware.ts                # Auth, plan gating, rate limiting
└── drizzle.config.ts
```

## Available Scripts

```bash
npm run dev           # Start dev server
npm run build         # Production build
npm run typecheck     # tsc --noEmit
npm run lint          # ESLint
npm run db:generate   # Drizzle generate migrations
npm run db:migrate    # Apply migrations
npm run db:studio     # Drizzle Studio GUI
npm run test          # Vitest unit tests
npm run test:e2e      # Playwright E2E
```

## Key Architectural Decisions

**Edge Middleware** — Auth via Clerk JWT at the edge (no DB hit per request). Plan gating via `x-user-plan` header set in middleware, read in RSC.

**RSC-first** — All `/app/*` pages are React Server Components fetching directly from Neon. No client-side data fetching on initial load.

**Parallel DB queries** — Dashboard uses `Promise.all()` with 10 parallel queries. Target: < 80ms p50.

**Premium gating** — Three-layer: middleware header → RSC conditional render → API 402 response. No separate codebase.

**Computed fields** — `durationMinutes`, `deviationMinutes`, `isLate`, `minutesAfterWindow`, `recoveryScore` are all computed server-side at write time and stored. Never computed on read.

## Deployment

Push to `main` → automatic Vercel deploy.

Required Vercel environment variables: see `.env.example`.

Vercel integrations to enable:
- Vercel KV (creates `UPSTASH_REDIS_REST_URL` + token)
- Vercel Edge Config (creates `EDGE_CONFIG`)
- Vercel Analytics (zero-config)

## Adding Premium Features

1. Check `user.plan` from Clerk metadata in middleware (already done)
2. In RSC: read `x-user-plan` header from `next/headers`
3. Wrap content in `<PremiumGate isLocked={plan !== "premium"}>`
4. In API routes: `if (user.plan !== "premium") return apiError("Upgrade required", 402)`
