"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Moon, Dumbbell, Utensils, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { href: "/app/dashboard", label: "Home", icon: LayoutDashboard },
  { href: "/app/sleep", label: "Sleep", icon: Moon },
  { href: "/app/exercise", label: "Exercise", icon: Dumbbell },
  { href: "/app/nutrition", label: "Nutrition", icon: Utensils },
  { href: "/app/settings", label: "More", icon: MoreHorizontal },
];

export function MobileBottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-white border-t border-surface-200 safe-area-pb">
      <div className="flex">
        {TABS.map((tab) => {
          const isActive = pathname === tab.href || (tab.href !== "/app/dashboard" && pathname.startsWith(tab.href));
          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={cn(
                "flex-1 flex flex-col items-center gap-1 py-3 text-[11px] font-medium transition-colors",
                isActive ? "text-brand-600" : "text-surface-400"
              )}
            >
              <tab.icon className={cn("w-5 h-5", isActive ? "text-brand-600" : "text-surface-400")} />
              {tab.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
