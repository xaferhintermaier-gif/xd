"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { UserButton } from "@clerk/nextjs";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Moon,
  Dumbbell,
  Utensils,
  Sun,
  TrendingUp,
  FileText,
  Settings,
  Zap,
} from "lucide-react";

interface SidebarUser {
  id: string;
  displayName: string;
  avatarUrl: string;
  plan: "free" | "premium";
}

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  premiumOnly?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/app/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/app/sleep", label: "Sleep", icon: Moon },
  { href: "/app/exercise", label: "Exercise", icon: Dumbbell },
  { href: "/app/nutrition", label: "Nutrition", icon: Utensils },
  { href: "/app/recovery", label: "Recovery", icon: Sun },
  { href: "/app/circadian", label: "Circadian", icon: Zap },
  { href: "/app/insights", label: "Insights", icon: TrendingUp, premiumOnly: true },
  { href: "/app/reports", label: "Reports", icon: FileText },
];

export function Sidebar({ user }: { user: SidebarUser }) {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex md:flex-col md:w-60 md:shrink-0 border-r border-surface-200 bg-white">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-surface-200">
        <Link href="/app/dashboard" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-brand-500 flex items-center justify-center">
            <span className="text-white font-bold text-sm">H</span>
          </div>
          <span className="font-semibold text-surface-900 text-sm tracking-tight">
            Health OS
          </span>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
          const isLocked = item.premiumOnly && user.plan !== "premium";

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-brand-50 text-brand-700"
                  : "text-surface-600 hover:bg-surface-50 hover:text-surface-900"
              )}
            >
              <item.icon className={cn("w-4 h-4 shrink-0", isActive ? "text-brand-600" : "text-surface-400")} />
              <span>{item.label}</span>
              {isLocked && (
                <span className="ml-auto text-[10px] font-semibold text-brand-600 bg-brand-50 border border-brand-200 px-1.5 py-0.5 rounded">
                  PRO
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Settings + User */}
      <div className="border-t border-surface-200 px-3 py-3 space-y-0.5">
        <Link
          href="/app/settings"
          className={cn(
            "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
            pathname.startsWith("/app/settings")
              ? "bg-brand-50 text-brand-700"
              : "text-surface-600 hover:bg-surface-50 hover:text-surface-900"
          )}
        >
          <Settings className="w-4 h-4 text-surface-400 shrink-0" />
          Settings
        </Link>

        <div className="flex items-center gap-3 px-3 py-2">
          <UserButton afterSignOutUrl="/" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-surface-900 truncate">
              {user.displayName}
            </p>
            <p className="text-[11px] text-surface-500 capitalize">{user.plan}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
