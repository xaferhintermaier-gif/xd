"use client";

import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Legend
} from "recharts";
import { format, parseISO } from "date-fns";
import { useState } from "react";
import { cn } from "@/lib/utils";

// ─── SleepDurationChart ───────────────────────────────────────────────────────

interface SleepDurationData {
  date: string;
  durationMinutes: number;
  targetMinutes: number;
}

export function SleepDurationChart({ data }: { data: SleepDurationData[] }) {
  const [range, setRange] = useState<"7d" | "30d">("7d");

  const displayed = range === "7d" ? data.slice(-7) : data.slice(-30);
  const formatted = displayed.map((d) => ({
    date: format(parseISO(d.date), "MMM d"),
    Actual: parseFloat((d.durationMinutes / 60).toFixed(1)),
    Target: parseFloat((d.targetMinutes / 60).toFixed(1)),
  }));

  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-surface-800">Sleep Duration</p>
        <div className="flex rounded-lg overflow-hidden border border-surface-200">
          {(["7d", "30d"] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={cn(
                "px-2.5 py-1 text-xs font-medium transition-colors",
                range === r ? "bg-brand-500 text-white" : "bg-white text-surface-500 hover:bg-surface-50"
              )}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={formatted} margin={{ left: -20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <YAxis unit="h" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <Tooltip
            contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }}
            formatter={(v: number) => [`${v}h`, ""]}
          />
          <Line dataKey="Target" stroke="#CBD5E1" strokeDasharray="4 4" dot={false} strokeWidth={1.5} />
          <Line dataKey="Actual" stroke="#00C2A8" strokeWidth={2} dot={{ r: 3, fill: "#00C2A8" }} activeDot={{ r: 5 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── RecoveryScoreLine ────────────────────────────────────────────────────────

interface RecoveryData {
  date: string;
  sleepQuality: number;
  mood: number;
  energyLevel: number;
  recoveryScore: number;
}

export function RecoveryScoreLine({ data }: { data: RecoveryData[] }) {
  const formatted = data.slice(-14).map((d) => ({
    date: format(parseISO(d.date), "MMM d"),
    Quality: d.sleepQuality,
    Mood: d.mood,
    Energy: d.energyLevel,
    Score: d.recoveryScore,
  }));

  return (
    <div className="card p-4">
      <p className="text-sm font-semibold text-surface-800 mb-4">Recovery (14 days)</p>
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={formatted} margin={{ left: -20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <YAxis domain={[0, 10]} tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
          <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
          <Line dataKey="Quality" stroke="#6366f1" strokeWidth={1.5} dot={false} />
          <Line dataKey="Mood" stroke="#f59e0b" strokeWidth={1.5} dot={false} />
          <Line dataKey="Energy" stroke="#10b981" strokeWidth={1.5} dot={false} />
          <Line dataKey="Score" stroke="#00C2A8" strokeWidth={2.5} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── ExerciseBarChart ─────────────────────────────────────────────────────────

interface ExerciseWeekData {
  week: string;
  sessions: number;
}

export function ExerciseBarChart({ data, goal }: { data: ExerciseWeekData[]; goal: number }) {
  const formatted = data.slice(-8).map((d) => ({
    week: d.week,
    Sessions: d.sessions,
    metGoal: d.sessions >= goal,
  }));

  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-surface-800">Weekly Sessions</p>
        <span className="text-xs text-surface-400">Goal: {goal}/week</span>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={formatted} margin={{ left: -20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
          <XAxis dataKey="week" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
          <ReferenceLine y={goal} stroke="#CBD5E1" strokeDasharray="4 4" label={{ value: "Goal", fontSize: 10, fill: "#94a3b8" }} />
          <Bar
            dataKey="Sessions"
            radius={[4, 4, 0, 0]}
            fill="#00C2A8"
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── SleepDebtChart ───────────────────────────────────────────────────────────

interface DebtData {
  date: string;
  debtMinutes: number;
}

export function SleepDebtChart({ data }: { data: DebtData[] }) {
  const formatted = data.slice(-14).map((d) => ({
    date: format(parseISO(d.date), "MMM d"),
    "Debt (min)": d.debtMinutes,
  }));

  return (
    <div className="card p-4">
      <p className="text-sm font-semibold text-surface-800 mb-4">Sleep Debt (14 days)</p>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={formatted} margin={{ left: -20 }}>
          <defs>
            <linearGradient id="debtGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15} />
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
          <Area dataKey="Debt (min)" stroke="#ef4444" fill="url(#debtGrad)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
