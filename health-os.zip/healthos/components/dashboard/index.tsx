"use client";

import { ProgressRing } from "@/components/ui";
import { formatTime12h, formatDuration } from "@/lib/utils";
import type { SleepDebt, MorningRecovery, ExerciseStreak, ExerciseGoal, CircadianSchedule, MealLog } from "@/types";
import { Moon, Dumbbell, Utensils, Sun, Plus, Coffee, Eye, Zap } from "lucide-react";
import Link from "next/link";

// ─── DailyScoreCard ───────────────────────────────────────────────────────────

interface DailyScoreCardProps {
  sleepDebt: SleepDebt;
  todayRecovery: MorningRecovery | null;
}

export function DailyScoreCard({ sleepDebt, todayRecovery }: DailyScoreCardProps) {
  const debtScore = Math.max(0, 100 - Math.round((sleepDebt.currentDebtMinutes / 600) * 100));
  const recoveryScore = todayRecovery ? Math.round(todayRecovery.recoveryScore * 10) : null;
  const consistencyScore = Math.round(sleepDebt.consistencyScore);

  return (
    <div className="card p-5">
      <p className="text-xs font-medium text-surface-500 uppercase tracking-wide mb-4">Today's Scores</p>
      <div className="flex items-center justify-around gap-4">
        <div className="flex flex-col items-center gap-2">
          <ProgressRing
            value={debtScore}
            max={100}
            size={88}
            color={debtScore >= 70 ? "#10b981" : debtScore >= 40 ? "#f59e0b" : "#ef4444"}
            label={`${debtScore}`}
            sublabel="/ 100"
          />
          <p className="text-xs font-medium text-surface-600">Debt Score</p>
        </div>
        <div className="flex flex-col items-center gap-2">
          <ProgressRing
            value={consistencyScore}
            max={100}
            size={88}
            color="#00C2A8"
            label={`${consistencyScore}`}
            sublabel="/ 100"
          />
          <p className="text-xs font-medium text-surface-600">Consistency</p>
        </div>
        <div className="flex flex-col items-center gap-2">
          {recoveryScore !== null ? (
            <ProgressRing
              value={recoveryScore}
              max={100}
              size={88}
              color={recoveryScore >= 70 ? "#10b981" : recoveryScore >= 40 ? "#f59e0b" : "#ef4444"}
              label={`${recoveryScore}`}
              sublabel="/ 100"
            />
          ) : (
            <div className="w-[88px] h-[88px] rounded-full border-2 border-dashed border-surface-200 flex items-center justify-center">
              <Plus className="w-5 h-5 text-surface-300" />
            </div>
          )}
          <p className="text-xs font-medium text-surface-600">Recovery</p>
        </div>
      </div>
    </div>
  );
}

// ─── TodayScheduleCard ────────────────────────────────────────────────────────

interface ScheduleEvent {
  time: string;
  label: string;
  icon: React.ElementType;
  color: string;
}

export function TodayScheduleCard({ schedule }: { schedule: CircadianSchedule }) {
  const events: ScheduleEvent[] = [
    { time: schedule.wakeTime, label: "Wake", icon: Sun, color: "text-amber-500" },
    { time: schedule.caffeineDeadline, label: "Last caffeine", icon: Coffee, color: "text-brown-500" },
    { time: schedule.mealWindowClose, label: "Eating window closes", icon: Utensils, color: "text-emerald-500" },
    { time: schedule.blueLightCutoff, label: "Blue light off", icon: Eye, color: "text-purple-500" },
    { time: schedule.targetBedtime, label: "Target bedtime", icon: Moon, color: "text-brand-500" },
  ];

  return (
    <div className="card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Zap className="w-4 h-4 text-brand-500" />
        <p className="text-xs font-semibold text-surface-700 uppercase tracking-wide">Today's Schedule</p>
      </div>
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
        {events.map((event, i) => (
          <div key={i} className="flex flex-col items-center gap-1 shrink-0">
            <event.icon className={`w-4 h-4 ${event.color}`} />
            <span className="text-[11px] font-bold text-surface-900 tabular-nums whitespace-nowrap">
              {formatTime12h(event.time)}
            </span>
            <span className="text-[10px] text-surface-400 whitespace-nowrap text-center max-w-[64px] leading-tight">
              {event.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── ExerciseWeekCard ────────────────────────────────────────────────────────

interface ExerciseWeekCardProps {
  sessionsCompleted: number;
  goal: ExerciseGoal;
  streak: ExerciseStreak;
  sessionDates?: string[]; // ISO dates
}

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export function ExerciseWeekCard({ sessionsCompleted, goal, streak }: ExerciseWeekCardProps) {
  const dots = Array.from({ length: 7 }, (_, i) => i < sessionsCompleted);

  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Dumbbell className="w-4 h-4 text-surface-400" />
          <p className="text-xs font-medium text-surface-500 uppercase tracking-wide">This Week</p>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-lg">🔥</span>
          <span className="text-sm font-bold text-orange-600">{streak.currentStreakWeeks}w</span>
        </div>
      </div>

      <div className="flex items-center gap-1.5 mb-3">
        {DAYS.map((day, i) => (
          <div key={day} className="flex-1 flex flex-col items-center gap-1">
            <div className={`w-full aspect-square rounded-md flex items-center justify-center ${
              dots[i]
                ? "bg-brand-500"
                : i < sessionsCompleted
                ? "bg-brand-200"
                : "bg-surface-100"
            }`}>
              {dots[i] && <span className="text-[10px] text-white">✓</span>}
            </div>
            <span className="text-[10px] text-surface-400">{day[0]}</span>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-surface-500">
          <span className="font-bold text-surface-900">{sessionsCompleted}</span>
          {" / "}{goal.sessionsPerWeek} sessions
        </p>
        <Link
          href="/app/exercise/log"
          className="text-xs font-semibold text-brand-600 hover:text-brand-700"
        >
          + Log session
        </Link>
      </div>
    </div>
  );
}

// ─── QuickLogBar ──────────────────────────────────────────────────────────────

interface QuickAction {
  label: string;
  href: string;
  icon: React.ElementType;
  color: string;
}

const QUICK_ACTIONS: QuickAction[] = [
  { label: "Sleep", href: "/app/sleep", icon: Moon, color: "bg-indigo-50 text-indigo-600 border-indigo-200 hover:bg-indigo-100" },
  { label: "Recovery", href: "/app/recovery", icon: Sun, color: "bg-amber-50 text-amber-600 border-amber-200 hover:bg-amber-100" },
  { label: "Exercise", href: "/app/exercise/log", icon: Dumbbell, color: "bg-emerald-50 text-emerald-600 border-emerald-200 hover:bg-emerald-100" },
  { label: "Meal", href: "/app/nutrition/log", icon: Utensils, color: "bg-pink-50 text-pink-600 border-pink-200 hover:bg-pink-100" },
];

export function QuickLogBar() {
  return (
    <div className="card p-4">
      <p className="text-xs font-medium text-surface-500 uppercase tracking-wide mb-3">Quick Log</p>
      <div className="grid grid-cols-2 gap-2">
        {QUICK_ACTIONS.map((action) => (
          <Link
            key={action.label}
            href={action.href}
            className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm font-medium transition-colors ${action.color}`}
          >
            <action.icon className="w-4 h-4" />
            {action.label}
          </Link>
        ))}
      </div>
    </div>
  );
}

// ─── PendingActionsAlert ──────────────────────────────────────────────────────

import type { PendingLog } from "@/types";
import { AlertCircle } from "lucide-react";

export function PendingActionsAlert({ pendingLogs }: { pendingLogs: PendingLog[] }) {
  if (pendingLogs.length === 0) return null;

  return (
    <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl">
      <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-amber-800">Missing logs</p>
        <div className="mt-1 flex flex-wrap gap-2">
          {pendingLogs.map((log) => (
            <Link
              key={log.type}
              href={log.href}
              className="text-xs font-medium text-amber-700 hover:text-amber-900 underline underline-offset-2"
            >
              {log.label}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
