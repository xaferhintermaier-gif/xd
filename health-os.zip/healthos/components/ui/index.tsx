import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Minus, Lock } from "lucide-react";
import Link from "next/link";

// ─── MetricCard ───────────────────────────────────────────────────────────────

interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  trend?: number;
  description?: string;
  className?: string;
}

export function MetricCard({ label, value, unit, trend, description, className }: MetricCardProps) {
  return (
    <div className={cn("card p-4", className)}>
      <p className="text-xs font-medium text-surface-500 uppercase tracking-wide">{label}</p>
      <div className="mt-1.5 flex items-baseline gap-1.5">
        <span className="text-2xl font-bold text-surface-900 tabular-nums">{value}</span>
        {unit && <span className="text-sm text-surface-500">{unit}</span>}
      </div>
      {(trend !== undefined || description) && (
        <div className="mt-1.5 flex items-center gap-1">
          {trend !== undefined && (
            <>
              {trend > 0 ? (
                <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
              ) : trend < 0 ? (
                <TrendingDown className="w-3.5 h-3.5 text-red-500" />
              ) : (
                <Minus className="w-3.5 h-3.5 text-surface-400" />
              )}
              <span className={cn(
                "text-xs font-medium",
                trend > 0 ? "text-emerald-600" : trend < 0 ? "text-red-500" : "text-surface-500"
              )}>
                {trend > 0 ? "+" : ""}{trend}%
              </span>
            </>
          )}
          {description && <span className="text-xs text-surface-500">{description}</span>}
        </div>
      )}
    </div>
  );
}

// ─── ProgressRing ─────────────────────────────────────────────────────────────

interface ProgressRingProps {
  value: number;
  max: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  label?: string;
  sublabel?: string;
}

export function ProgressRing({
  value,
  max,
  size = 80,
  strokeWidth = 6,
  color = "#00C2A8",
  label,
  sublabel,
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(value / max, 1);
  const offset = circumference * (1 - progress);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#E2E8F0"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-700 ease-out"
        />
      </svg>
      {(label || sublabel) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {label && <span className="text-sm font-bold text-surface-900 leading-none">{label}</span>}
          {sublabel && <span className="text-[10px] text-surface-500 mt-0.5">{sublabel}</span>}
        </div>
      )}
    </div>
  );
}

// ─── ScorePill ────────────────────────────────────────────────────────────────

interface ScorePillProps {
  score: number;
  max?: number;
  label: string;
  variant?: "sleep" | "exercise" | "recovery" | "default";
}

function getScoreColor(score: number, max: number) {
  const pct = score / max;
  if (pct >= 0.7) return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (pct >= 0.4) return "bg-amber-50 text-amber-700 border-amber-200";
  return "bg-red-50 text-red-600 border-red-200";
}

export function ScorePill({ score, max = 10, label }: ScorePillProps) {
  return (
    <div className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold", getScoreColor(score, max))}>
      <span>{label}</span>
      <span className="font-bold">{score.toFixed(1)}</span>
      <span className="opacity-60">/ {max}</span>
    </div>
  );
}

// ─── StreakBadge ──────────────────────────────────────────────────────────────

export function StreakBadge({ count, unit = "weeks" }: { count: number; unit?: string }) {
  return (
    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-orange-50 border border-orange-200 rounded-full">
      <span className="text-base">🔥</span>
      <span className="text-sm font-bold text-orange-700">{count}</span>
      <span className="text-xs text-orange-600">{unit}</span>
    </div>
  );
}

// ─── PremiumGate ──────────────────────────────────────────────────────────────

interface PremiumGateProps {
  children: React.ReactNode;
  isLocked: boolean;
  upgradeHref?: string;
}

export function PremiumGate({ children, isLocked, upgradeHref = "/app/settings/billing" }: PremiumGateProps) {
  if (!isLocked) return <>{children}</>;

  return (
    <div className="relative">
      <div className="pointer-events-none select-none blur-sm opacity-60">{children}</div>
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 backdrop-blur-sm rounded-xl">
        <div className="flex flex-col items-center gap-3 p-6 text-center">
          <div className="w-10 h-10 rounded-full bg-brand-50 border border-brand-200 flex items-center justify-center">
            <Lock className="w-5 h-5 text-brand-600" />
          </div>
          <div>
            <p className="font-semibold text-surface-900 text-sm">Premium Feature</p>
            <p className="text-xs text-surface-500 mt-0.5">Upgrade to unlock correlation analysis</p>
          </div>
          <Link
            href={upgradeHref}
            className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Upgrade to Premium
          </Link>
        </div>
      </div>
    </div>
  );
}

// ─── EmptyState ───────────────────────────────────────────────────────────────

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: { label: string; href?: string; onClick?: () => void };
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      {icon && <div className="mb-4 text-surface-300">{icon}</div>}
      <h3 className="text-sm font-semibold text-surface-900">{title}</h3>
      <p className="mt-1 text-sm text-surface-500 max-w-xs">{description}</p>
      {action && (
        <div className="mt-4">
          {action.href ? (
            <Link
              href={action.href}
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors"
            >
              {action.label}
            </Link>
          ) : (
            <button
              onClick={action.onClick}
              className="px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium rounded-lg transition-colors"
            >
              {action.label}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── PageHeader ───────────────────────────────────────────────────────────────

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}

export function PageHeader({ title, description, actions }: PageHeaderProps) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h1 className="text-xl font-bold text-surface-900">{title}</h1>
        {description && <p className="mt-0.5 text-sm text-surface-500">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

// ─── SleepDebtMeter ──────────────────────────────────────────────────────────

export function SleepDebtMeter({ debtMinutes }: { debtMinutes: number }) {
  const maxDebt = 600; // 10 hours
  const pct = Math.min(debtMinutes / maxDebt, 1);
  const color = pct < 0.3 ? "#10b981" : pct < 0.6 ? "#f59e0b" : "#ef4444";
  const label = pct < 0.3 ? "Low" : pct < 0.6 ? "Moderate" : "High";

  const hours = Math.floor(debtMinutes / 60);
  const mins = debtMinutes % 60;

  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-medium text-surface-500 uppercase tracking-wide">Sleep Debt</p>
        <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ color, backgroundColor: color + "15" }}>
          {label}
        </span>
      </div>
      <p className="text-2xl font-bold text-surface-900 tabular-nums mb-3">
        {hours > 0 ? `${hours}h ` : ""}{mins}m
      </p>
      <div className="w-full h-2 bg-surface-100 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${pct * 100}%`, backgroundColor: color }}
        />
      </div>
      <p className="mt-2 text-xs text-surface-400">Rolling 14-day deficit</p>
    </div>
  );
}
