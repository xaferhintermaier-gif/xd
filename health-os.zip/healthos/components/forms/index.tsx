"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";

// ─── RatingSlider ─────────────────────────────────────────────────────────────

interface RatingSliderProps {
  label: string;
  value: number;
  onChange: (v: number) => void;
  lowLabel?: string;
  highLabel?: string;
}

export function RatingSlider({ label, value, onChange, lowLabel = "Poor", highLabel = "Excellent" }: RatingSliderProps) {
  const color = value >= 7 ? "#10b981" : value >= 4 ? "#f59e0b" : "#ef4444";

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-surface-700">{label}</label>
        <span className="text-xl font-bold tabular-nums" style={{ color }}>{value}</span>
      </div>
      <input
        type="range"
        min={1}
        max={10}
        step={1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-2 rounded-full cursor-pointer accent-brand-500"
        aria-label={label}
        aria-valuenow={value}
        aria-valuemin={1}
        aria-valuemax={10}
      />
      <div className="flex justify-between">
        <span className="text-[11px] text-surface-400">{lowLabel}</span>
        <span className="text-[11px] text-surface-400">{highLabel}</span>
      </div>
    </div>
  );
}

// ─── RecoveryForm ─────────────────────────────────────────────────────────────

const recoverySchema = z.object({
  sleepQuality: z.number().min(1).max(10),
  mood: z.number().min(1).max(10),
  energyLevel: z.number().min(1).max(10),
});

type RecoveryFormData = z.infer<typeof recoverySchema>;

export function RecoveryForm({ date, onSuccess }: { date: string; onSuccess?: () => void }) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scores, setScores] = useState({ sleepQuality: 7, mood: 7, energyLevel: 7 });
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const res = await fetch("/api/recovery", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ date, ...scores }),
    });

    const data = await res.json();
    setIsLoading(false);

    if (!res.ok) {
      setError(data.error ?? "Something went wrong");
      return;
    }

    onSuccess?.();
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <RatingSlider
        label="Sleep Quality"
        value={scores.sleepQuality}
        onChange={(v) => setScores((s) => ({ ...s, sleepQuality: v }))}
        lowLabel="Terrible"
        highLabel="Perfect"
      />
      <RatingSlider
        label="Mood"
        value={scores.mood}
        onChange={(v) => setScores((s) => ({ ...s, mood: v }))}
        lowLabel="Awful"
        highLabel="Great"
      />
      <RatingSlider
        label="Energy Level"
        value={scores.energyLevel}
        onChange={(v) => setScores((s) => ({ ...s, energyLevel: v }))}
        lowLabel="Exhausted"
        highLabel="Energized"
      />

      {error && <p className="text-sm text-red-500">{error}</p>}

      <button
        type="submit"
        disabled={isLoading}
        className="w-full py-3 px-4 bg-brand-500 hover:bg-brand-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-colors"
      >
        {isLoading ? "Saving..." : "Save Recovery Log"}
      </button>
    </form>
  );
}

// ─── SleepLogForm ─────────────────────────────────────────────────────────────

const sleepLogSchema = z.object({
  bedtime: z.string().min(1, "Required"),
  wakeTime: z.string().min(1, "Required"),
  date: z.string(),
});

type SleepLogFormData = z.infer<typeof sleepLogSchema>;

export function SleepLogForm({ defaultDate, onSuccess }: { defaultDate: string; onSuccess?: () => void }) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<SleepLogFormData>({
    resolver: zodResolver(sleepLogSchema),
    defaultValues: { date: defaultDate },
  });
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function onSubmit(data: SleepLogFormData) {
    setError(null);
    const res = await fetch("/api/sleep/logs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!res.ok) { setError(json.error ?? "Something went wrong"); return; }
    onSuccess?.();
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <input type="hidden" {...register("date")} />

      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Bedtime</label>
        <input
          type="datetime-local"
          {...register("bedtime")}
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
        />
        {errors.bedtime && <p className="text-xs text-red-500">{errors.bedtime.message}</p>}
      </div>

      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Wake Time</label>
        <input
          type="datetime-local"
          {...register("wakeTime")}
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
        />
        {errors.wakeTime && <p className="text-xs text-red-500">{errors.wakeTime.message}</p>}
      </div>

      {error && <p className="text-sm text-red-500">{error}</p>}

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-3 px-4 bg-brand-500 hover:bg-brand-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-colors"
      >
        {isSubmitting ? "Saving..." : "Log Sleep"}
      </button>
    </form>
  );
}

// ─── ExerciseSessionForm ──────────────────────────────────────────────────────

const EXERCISE_TYPES = ["strength", "cardio", "hiit", "yoga", "sport", "walk", "other"] as const;

const exerciseSchema = z.object({
  sessionDate: z.string().min(1, "Required"),
  type: z.enum(EXERCISE_TYPES),
  durationMinutes: z.coerce.number().min(1).max(480).optional(),
  intensityRating: z.coerce.number().min(1).max(10).optional(),
  notes: z.string().max(500).optional(),
});

type ExerciseFormData = z.infer<typeof exerciseSchema>;

export function ExerciseSessionForm({ defaultDate, onSuccess }: { defaultDate: string; onSuccess?: () => void }) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<ExerciseFormData>({
    resolver: zodResolver(exerciseSchema),
    defaultValues: { sessionDate: defaultDate, type: "strength" },
  });
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function onSubmit(data: ExerciseFormData) {
    setError(null);
    const res = await fetch("/api/exercise/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!res.ok) { setError(json.error ?? "Something went wrong"); return; }
    onSuccess?.();
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Date</label>
        <input
          type="date"
          {...register("sessionDate")}
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Type</label>
        <select
          {...register("type")}
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition capitalize"
        >
          {EXERCISE_TYPES.map((t) => (
            <option key={t} value={t} className="capitalize">{t}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-surface-700">Duration (min)</label>
          <input
            type="number"
            {...register("durationMinutes")}
            placeholder="45"
            className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-surface-700">Intensity (RPE)</label>
          <input
            type="number"
            min={1}
            max={10}
            {...register("intensityRating")}
            placeholder="7"
            className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Notes</label>
        <textarea
          {...register("notes")}
          rows={2}
          placeholder="Optional notes..."
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition resize-none"
        />
      </div>

      {error && <p className="text-sm text-red-500">{error}</p>}

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-3 px-4 bg-brand-500 hover:bg-brand-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-colors"
      >
        {isSubmitting ? "Saving..." : "Log Session"}
      </button>
    </form>
  );
}

// ─── MealLogForm ──────────────────────────────────────────────────────────────

const MEAL_LABELS = ["Breakfast", "Lunch", "Dinner", "Snack", "Other"];

const mealSchema = z.object({
  loggedAt: z.string().min(1, "Required"),
  mealLabel: z.string().optional(),
  notes: z.string().max(300).optional(),
});

type MealFormData = z.infer<typeof mealSchema>;

export function MealLogForm({ onSuccess }: { onSuccess?: () => void }) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<MealFormData>({
    resolver: zodResolver(mealSchema),
    defaultValues: { loggedAt: new Date().toISOString().slice(0, 16) },
  });
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function onSubmit(data: MealFormData) {
    setError(null);
    const res = await fetch("/api/nutrition/meals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!res.ok) { setError(json.error ?? "Something went wrong"); return; }
    onSuccess?.();
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Time</label>
        <input
          type="datetime-local"
          {...register("loggedAt")}
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Meal</label>
        <div className="flex flex-wrap gap-2">
          {MEAL_LABELS.map((label) => (
            <label key={label} className="flex items-center gap-1.5 cursor-pointer">
              <input type="radio" {...register("mealLabel")} value={label} className="accent-brand-500" />
              <span className="text-sm text-surface-700">{label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-sm font-medium text-surface-700">Notes</label>
        <input
          type="text"
          {...register("notes")}
          placeholder="Optional..."
          className="w-full px-3 py-2.5 rounded-lg border border-surface-200 bg-white text-sm focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition"
        />
      </div>

      {error && <p className="text-sm text-red-500">{error}</p>}

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-3 px-4 bg-brand-500 hover:bg-brand-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-colors"
      >
        {isSubmitting ? "Saving..." : "Log Meal"}
      </button>
    </form>
  );
}
