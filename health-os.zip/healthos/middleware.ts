import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const isPublicRoute = createRouteMatcher([
  "/",
  "/features",
  "/how-it-works",
  "/pricing",
  "/about",
  "/changelog",
  "/blog(.*)",
  "/legal(.*)",
  "/sign-in(.*)",
  "/sign-up(.*)",
  "/api/webhook/(.*)",
]);

const isAppRoute = createRouteMatcher(["/app(.*)"]);
const isOnboardingRoute = createRouteMatcher(["/onboarding(.*)"]);

export default clerkMiddleware(async (auth, req: NextRequest) => {
  const { userId, sessionClaims } = await auth();

  // Allow public routes without auth
  if (isPublicRoute(req)) {
    return NextResponse.next();
  }

  // Require auth for all other routes
  if (!userId) {
    const signInUrl = new URL("/sign-in", req.url);
    signInUrl.searchParams.set("redirect_url", req.url);
    return NextResponse.redirect(signInUrl);
  }

  const metadata = sessionClaims?.metadata as {
    onboarded?: boolean;
    plan?: "free" | "premium";
  } | undefined;

  const onboarded = metadata?.onboarded ?? false;
  const plan = metadata?.plan ?? "free";

  // Redirect to onboarding if not completed
  if (!onboarded && isAppRoute(req)) {
    return NextResponse.redirect(new URL("/onboarding", req.url));
  }

  // Redirect away from onboarding if already completed
  if (onboarded && isOnboardingRoute(req)) {
    return NextResponse.redirect(new URL("/app/dashboard", req.url));
  }

  // Attach plan to response headers for RSC consumption
  const response = NextResponse.next();
  response.headers.set("x-user-id", userId);
  response.headers.set("x-user-plan", plan);

  return response;
});

export const config = {
  matcher: ["/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)","/(api|trpc)(.*)"],
};
